Insurance request tools

This library implement an trait for period price calculation based of a supplier for (insurance) products.

###Local and virtual Requirements
- PHP >= 7.0.0
- Illumintate http lib
- composer

###Basic usage

- Get library as dependency via composer add following to your require section in composer.json:
```json
  {
      "repositories": [
          {
            "type": "composer",
            "url": "https://nexus.verivox.ads/repository/verivox-composer"
        },
      ],
    "require": {
        "verivox/insurance.request.tools": "<VERSION>"
    }
  }
```
- Run composer update in your project to fetch all dependencies

###Development
- If you adjust the client IP parse, don't forget to adjust the [VX Insurance Docker Baseimages](http://bitbucket.verivox.ads/projects/MOD/repos/insurance.docker.baseimages/browse)


###How to use

```php

use \RequestTools\Traits\Request;

$userIp = $service->fetchUserIp($request);
```
###UnitTesting

- Run the the tests
```
./bin/test
```
