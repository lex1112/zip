##Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [0.1.0] - 2017-03-28
### Added
- A trait to get the user ip.
- change .gitignore in .gitkeep

## [0.2.0] - 2017-06-27
### Added
- A function to convert utf8 parameters to ISO-88659-1 recursively

## [0.2.1] - 2017-06-30
### fix
- fixing the name of convertUtf8ParameterToIso method  and the parameter list

## [1.0.0] - 2017-09-08
### update
- increase illuminate/http

## [1.1.0] - 2017-09-23
### Added
- functions to enrich the request options with the partnerId, NoCache parameter and user information

## [1.2.0] - 2017-09-24
### Added
- functions to enrich the request options with debug parameters

## [2.0.0] - 2018-01-12
### Added
- functions to enrich the request options with profile parameter

## [2.1.0] - 2018-02-08
### Added
- extend functions to enrich the request options with debug parameters
  - use the cookie, query and body parameters

## [2.1.1] - 2018-03-17
### Fixed
- the fetchUserIp function
  - now the parameters are evaluated close to the production system and HTTP_X_ORIGINAL_FORWARDED_FOR and HTTP_X_REAL_IP are also considered

## [3.0.0] - 2019-03-15
### update
- remove function which enrich the request options with the partnerId