<?php

namespace tests\unit;

use RequestTools\Traits\Request;

/**
 *
 * Class RequestTest
 *
 * @copyright Verivox GmbH 2017
 * @license   proprietary
 */
class RequestTest extends \Codeception\Test\Unit
{
    use Request;

    public function testFetchUserIp()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], [
            'REMOTE_ADDR' => '127.0.0.1', 'HTTP_X_FORWARDED_FOR' => '127.0.0.2', 'HTTP_X_CLIENT_IP' => '127.0.0.3'
        ]);
        $this->assertEquals('127.0.0.2', $this->fetchUserIp($request));

        $request = new \Illuminate\Http\Request([], [], [], [], [], [
            'REMOTE_ADDR' => '127.0.0.1', 'HTTP_X_CLIENT_IP' => '127.0.0.3'
        ]);
        $this->assertEquals('127.0.0.3', $this->fetchUserIp($request));

        $request = new \Illuminate\Http\Request([], [], [], [], [], []);
        $this->assertEquals('', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithRemoteAddr()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['REMOTE_ADDR' => '127.0.0.1']);
        $this->assertEquals('127.0.0.1', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithXForwardedFor()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_FORWARDED_FOR' => '127.0.0.2']);
        $this->assertEquals('127.0.0.2', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithXClientIp()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_CLIENT_IP' => '127.0.0.3']);
        $this->assertEquals('127.0.0.3', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithRemoteAddrWithIpv6Stuff()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['REMOTE_ADDR' => '::127.0.0.1']);
        $this->assertEquals('127.0.0.1', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithXForwardedForIpv6Stuff()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_FORWARDED_FOR' => '::127.0.0.2']);
        $this->assertEquals('127.0.0.2', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithXClientIpIpv6Stuff()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_CLIENT_IP' => '::127.0.0.3']);
        $this->assertEquals('127.0.0.3', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithXOriginalForwarededFor()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_ORIGINAL_FORWARDED_FOR' => '83.137.191.1, 83.137.191.1:0']);
        $this->assertEquals('83.137.191.1', $this->fetchUserIp($request));
    }

    public function testFetchUserIpWithXRealIp()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_REAL_IP' => '83.137.191.1']);
        $this->assertEquals('83.137.191.1', $this->fetchUserIp($request));
    }

    /**
     * a example with the logged live header
     */
    public function testFetchUserIpWithTheLiveHeaders()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], [
            'HTTP_X_ORIGINAL_FORWARDED_FOR' => '83.137.191.1, 83.137.191.1:0',
            'HTTP_X_FORWARDED_HOST' => '35.187.65.178',
            'HTTP_X_FORWARDED_FOR' => '83.137.185.11', // reverse proxy address
            'HTTP_X_REAL_IP' => '83.137.185.11',
            'HTTP_HOST' => '35.187.65.178', // node ip
            'SERVER_ADDR' => '10.4.3.114', // internal pod address
            'REMOTE_ADDR' => '10.4.2.179',
        ]);
        $this->assertEquals('83.137.191.1', $this->fetchUserIp($request));
    }

    public function testConvertUtf8ToIsoParameters()
    {
        $parameters = [
            'größe' => [
                'ü18' => ['test'],
                'öäü' => true,
            ],
            'äöüß' => 'llkkj',
            'üöäöüß',
            'test' => 'test'
        ];

        $this->assertEquals(
            [
                utf8_decode('größe') => [
                    utf8_decode('ü18') => ['test'],
                    utf8_decode('öäü') => true,
                ],
                utf8_decode('äöüß') => 'llkkj',
                utf8_decode('üöäöüß'),
                'test' => 'test'
            ],
            $this->convertUtf8ParameterToIso($parameters)
        );
    }



    public function testAddUserInfoToRequestOptionsWithRemoteAddr()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['REMOTE_ADDR' => '127.0.0.1']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addUserInfoToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            [
                'query' => ['eventHash' => 'f528764d624db129b32c21fbca0cb8d6',],
                'headers' => ['X-Client-IP' => '127.0.0.1', 'X-Forwarded-For' => '127.0.0.1',],
            ],
            $options
        );
    }

    public function testAddUserInfoToRequestOptionsWithXForwardedFor()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_FORWARDED_FOR' => '127.0.0.2']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addUserInfoToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            [
                'query' => ['eventHash' => 'ab416c39d509e72c5a0a7451a45bc65e',],
                'headers' => ['X-Client-IP' => '127.0.0.2', 'X-Forwarded-For' => '127.0.0.2',],
            ],
            $options
        );
    }

    public function testAddUserInfoToRequestOptionsWithXClientIp()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_CLIENT_IP' => '127.0.0.3']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addUserInfoToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            [
                'query' => ['eventHash' => '94084e434024aa1b2db3b06c7e4fa0f1',],
                'headers' => ['X-Client-IP' => '127.0.0.3', 'X-Forwarded-For' => '127.0.0.3',],
            ],
            $options
        );
    }

    public function testAddUserInfoToRequestOptionsWithRemoteAddrWithIpv6Stuff()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['REMOTE_ADDR' => '::127.0.0.1']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addUserInfoToRequestOptions($request, $options, 'formParams'));
        $this->assertEquals(
            [
                'formParams' => ['eventHash' => 'f528764d624db129b32c21fbca0cb8d6',],
                'headers' => ['X-Client-IP' => '127.0.0.1', 'X-Forwarded-For' => '127.0.0.1',],
            ],
            $options
        );
    }

    public function testAddUserInfoToRequestOptionsWithXForwardedForIpv6Stuff()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_FORWARDED_FOR' => '::127.0.0.2']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addUserInfoToRequestOptions($request, $options, 'formParams'));
        $this->assertEquals(
            [
                'formParams' => ['eventHash' => 'ab416c39d509e72c5a0a7451a45bc65e',],
                'headers' => ['X-Client-IP' => '127.0.0.2', 'X-Forwarded-For' => '127.0.0.2',],
            ],
            $options
        );
    }

    public function testAddUserInfoToRequestOptionsWithXClientIpIpv6Stuff()
    {
        $request = new \Illuminate\Http\Request([], [], [], [], [], ['HTTP_X_CLIENT_IP' => '::127.0.0.3']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addUserInfoToRequestOptions($request, $options, 'formParams'));
        $this->assertEquals(
            [
                'formParams' => ['eventHash' => '94084e434024aa1b2db3b06c7e4fa0f1',],
                'headers' => ['X-Client-IP' => '127.0.0.3', 'X-Forwarded-For' => '127.0.0.3',],
            ],
            $options
        );
    }

    public function testAddProfileParamToRequestOptionsWithId()
    {
        $request = new \Illuminate\Http\Request(['profile' => 'abc']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addProfileParamToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            ['query' => ['profile' => 'abc',],], $options
        );
    }

    public function testAddProfileParamToRequestOptionsWithoutId()
    {
        $request = new \Illuminate\Http\Request([]);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addProfileParamToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            [], $options
        );
    }

    public function testAddNoCacheParamsToRequestOptionsWithId()
    {
        $request = new \Illuminate\Http\Request(['noCache' => '1']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addNoCacheParamsToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            ['query' => ['noCache' => true,],], $options
        );
    }
    public function testAddNoCacheParamsToRequestOptionsWithoutId()
    {
        $request = new \Illuminate\Http\Request([]);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addNoCacheParamsToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            [], $options
        );
    }
    public function testAddDebugToRequestOptionsWithId()
    {
        $request = new \Illuminate\Http\Request(['XDEBUG_SESSION_START' => '1']);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addDebugToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            ['query' => ['XDEBUG_SESSION_START' => true,],], $options
        );
    }
    public function testAddDebugToRequestOptionsWithoutId()
    {
        $request = new \Illuminate\Http\Request([]);
        $options = [];
        $this->assertInstanceOf(self::class, $this->addDebugToRequestOptions($request, $options, 'query'));
        $this->assertEquals(
            [], $options
        );
    }
}