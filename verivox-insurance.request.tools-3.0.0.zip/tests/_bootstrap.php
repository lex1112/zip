<?php
include __DIR__ . '/../vendor/autoload.php';
define('TEST_DIR', __DIR__);
