<?php
namespace RequestTools\Traits;

use Illuminate\Http\Request as RequestEntity;
/**
 * trait to fetch the user ip
 *
 * @author René Werner <rene.werner@verviox.com>
 * @copyright Copyright (c) 2017 Verivox
 */
trait Request
{

    /**
     * fetch the user ip from request
     *
     * @param RequestEntity $request
     *
     * @return string
     */
    public function fetchUserIp(RequestEntity $request) : string {
        $headers = $request->headers->all();
        $userIp = '';
        // the order is important
        if (isset($headers['x-original-forwarded-for'][0])) {
            $userIp = $this->fetchIpFromString($headers['x-original-forwarded-for'][0]);
        }
        if ('' === $userIp && isset($headers['x-forwarded-for'][0])) {
            $userIp = $this->fetchIpFromString($headers['x-forwarded-for'][0]);
        }
        if ('' === $userIp && isset($headers['x-real-ip'][0])) {
            $userIp = $this->fetchIpFromString($headers['x-real-ip'][0]);
        }
        if ('' === $userIp) {
            if (isset($headers['x-client-ip'][0])) {
                $userIp = $this->fetchIpFromString($headers['x-client-ip'][0]);
            } else {
                $userIp = $this->fetchIpFromString((string) $request->ip());
            }
        }

        return $userIp;
    }

    /**
     * convert a list of parameters from uft8 encoding to ISO-88659-1 recursively
     * so sometimes we need the orginal parameter
     *
     *
     * @param array $parameters
     *
     * @return array
     */
    public function convertUtf8ParameterToIso(array $parameters) : array
    {
        foreach ($parameters as $key => $parameter) {
            if (is_array($parameter)) {
                $parameters[$key] = $this->convertUtf8ParameterToIso($parameter);
            } elseif (is_string($parameter)) {
                $parameters[$key] = utf8_decode($parameter);
            }
            if (is_string($key)) {
                $idx = $parameters[$key];
                unset($parameters[$key]);
                $parameters[utf8_decode($key)] = $idx;
            }
        }

        return $parameters;
    }


    /**
     * enrich the options with the user information from the current request
     *
     * @param RequestEntity $request
     * @param array $options
     * @param string $optionsKey
     *
     * @return self
     */
    public function addUserInfoToRequestOptions(
        RequestEntity $request,
        array &$options,
        string $optionsKey = 'query'
    ): self {
        $userIp = $this->fetchUserIp($request);
        $options[$optionsKey]['eventHash'] = $request->input('eventHash', md5($userIp));
        $options['headers']['X-Client-IP'] = $userIp;
        $options['headers']['X-Forwarded-For'] = $userIp;

        return $this;
    }

    /**
     * enrich the options with the no cache param from the current request
     *
     * @param RequestEntity $request
     * @param array $options
     * @param string $optionsKey
     *
     * @return self
     */
    public function addNoCacheParamsToRequestOptions(
        RequestEntity $request,
        array &$options,
        string $optionsKey = 'query'
    ): self {
        if (in_array($request->input('noCache', false), ['true', '1'], true)) {
            $options[$optionsKey]['noCache'] = true;
        }

        return $this;
    }

    /**
     * enrich the options with the debug param from the current request
     *
     * @param RequestEntity $request
     * @param array $options
     * @param string $optionsKey
     *
     * @return self
     */
    public function addDebugToRequestOptions(
        RequestEntity $request,
        array &$options,
        string $optionsKey = 'query'
    ): self {
        if ((bool) $request->input('XDEBUG_SESSION_START', false)
            || (true === $request->hasCookie('XDEBUG_SESSION_START') && (bool) $request->cookie('XDEBUG_SESSION_START'))
        ) {
            $options[$optionsKey]['XDEBUG_SESSION_START'] = true;
        }

        return $this;
    }

    /**
     * enrich the options with the profile parameter from the current request
     *
     * @param RequestEntity $request
     * @param array $options
     * @param string $optionsKey
     *
     * @return self
     */
    public function addProfileParamToRequestOptions(
        RequestEntity $request,
        array &$options,
        string $optionsKey = 'query'
    ): self {
        if (true === $request->has('profile')) {
            $options[$optionsKey]['profile'] = $request->input('profile');
        }

        return $this;
    }

    /**
     * hack - remote_addr will build by set_real_ip_from in ipv6 format, so we have to match the user IP without the real_ip ipv6 stuff
     *
     * @param string $userIp
     *
     * @return string
     */
    private function fetchIpFromString(string $userIp): string
    {
        preg_match('/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/', $userIp, $matches);

        return $matches[0] ?? '';
    }
}
