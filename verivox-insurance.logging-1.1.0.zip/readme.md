## Insurance logging

This library provides a simple logging configurator that initializes masked logging, removing all sensitive data from application logging.

### Local and virtual Requirements
- PHP >= 7.1.0
- Magoo >= 2.1.0
- composer

### Basic usage

- Get library as dependency via composer add following to your require section in composer.json:
```json
  {
      "repositories": [
          {
            "type": "composer",
            "url": "https://nexus.verivox.ads/repository/verivox-composer",
          }
      ],
    "require": {
        "verivox/insurance.logging": "<VERSION>"
      }
  }
```
- Run composer update in your project to fetch all dependencies

### How to use
Add the following to your bootstrap/app.php
```php
$app->configureMonologUsing(\Insurance\Logging\MaskedMonologLogger::createDefaultLumenLogger());

// additional loggers may be initialized like this
$app->singleton('additionalLog', function() {
    return new \Insurance\Logging\MaskedMonologLogger(
        'additionalChannel',
        [(new \Monolog\Handler\StreamHandler(storage_path() . '/logs/additional.log', 0, \Monolog\Logger::CRITICAL, 0777))]
    );
});


```
### UnitTesting

Note: You need to execute the bootstrap command initial:
 ```
bin/php vendor/bin/codecept bootstrap
```

- Run the the tests
```
./bin/test
```
