<?php

namespace Insurance\LoggingTest\Mask;

use Insurance\Logging\Mask\Url;

/**
 * Testing class for url masking.
 */
class UrlTest extends \Codeception\Test\Unit
{

    /**
     * @var array Strings containing valid urls with their masked variant
     */
    protected $validUrls = [
        '[2018-03-20 14:23:36] lumen.ERROR: GuzzleHttp\Exception\ClientException: Client error: `GET https://test.org/signup?firstName=Bob&phoneNumbe'
            . 'r=0341555666&foo=bar#top' => '[2018-03-20 14:23:36] lumen.ERROR: GuzzleHttp\Exception\ClientException: Client error: `GET https://test'
            . '.org/signup?firstName=***&phoneNumber=**********&foo=bar#top',
        'sftp://user:password@test.org' => 'sftp://test.org',
        '[2018-03-28 14:46:06] lumen.ERROR: GuzzleHttp\Exception\ServerException: Server error: `GET http://search-mrmoney-nginx/hhi/search?zip=06811'
            . '&city=Coswig&street=Alte Försjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjterei&streetNumber=324&dateOfBirth=09.03.1800&ap'
            . 'artmentType=multi-family-house&liveSpaceInHouse=80&jobStatus=employee&insuranceSum=ownSpecification&ownInsuranceSum=3243333&bicycleThe'
            . 'ft=0&glassInsurance=0&elementaryDamage=0&coInsuranceGrossNegligence=no&constructionClass=bak1&selfParticipation=0&minimumContractTerm='
            . '1&insuranceExchange=0&damages=0-damages&underinsuranceLiability=yes&surgeArresters=yes&theftBabyCarriagesWheelchairs=no&theftOutOfVehi'
            . 'cles=no&theftOfClothes=no&damageDeflagrationSmokeAndSoot=no&damageLandVehicles=no&valuableArticleInBankCustody=no&theftGardenFurniture'
            . '=no&waterDamage=no&heatDamage=no&pipeBreakage=no&returnTravelCosts=no&hotelCost=no&homeOffice=no&advancedPrecaution=no&allCover=no&sec'
            . 'urityLocks=yes&burglarAlarmSystem=no&tresor=no&uninterrupted=no&fireDanger=no&cost[selectedMaxValue]=1&wayOfPayment=12&vxRating=all&ev'
            . 'entHash=7a18803dd4cb0ca035285a09bf518209` resulted in a `502 Bad Gateway` response:' => '[2018-03-28 14:46:06] lumen.ERROR: GuzzleHttp'
            . '\Exception\ServerException: Server error: `GET http://search-mrmoney-nginx/hhi/search?zip=06811&city=Coswig&street=*******************'
            . '*****************************************************&streetNumber=***&dateOfBirth=**********&apartmentType=multi-family-house&liveSpa'
            . 'ceInHouse=80&jobStatus=employee&insuranceSum=ownSpecification&ownInsuranceSum=3243333&bicycleTheft=0&glassInsurance=0&elementaryDamage'
            . '=0&coInsuranceGrossNegligence=no&constructionClass=bak1&selfParticipation=0&minimumContractTerm=1&insuranceExchange=0&damages=0-damage'
            . 's&underinsuranceLiability=yes&surgeArresters=yes&theftBabyCarriagesWheelchairs=no&theftOutOfVehicles=no&theftOfClothes=no&damageDeflag'
            . 'rationSmokeAndSoot=no&damageLandVehicles=no&valuableArticleInBankCustody=no&theftGardenFurniture=no&waterDamage=no&heatDamage=no&pipeB'
            . 'reakage=no&returnTravelCosts=no&hotelCost=no&homeOffice=no&advancedPrecaution=no&allCover=no&securityLocks=yes&burglarAlarmSystem=no&t'
            . 'resor=no&uninterrupted=no&fireDanger=no&cost[selectedMaxValue]=1&wayOfPayment=12&vxRating=all&eventHash=7a18803dd4cb0ca035285a09bf5182'
            . '09` resulted in a `502 Bad Gateway` response:',
    ];

    /**
     * @var array Strings without any url masking
     */
    protected $invalidUrls = [
        'This string doesn\'t contain an url',
        'This string contains the url "http://www.www.www/www?foo=bar#top" with no sensitive data',
    ];

    /**
     * @var Url
     */
    protected $urlMask;

    protected function setUp()
    {
        $this->urlMask = new Url(['params' => ['dateOfBirth', 'street', 'streetNumber', 'firstName', 'lastName', 'phoneNumber']]);

    }

    /**
     * Test that the constructor works
     */
    public function testConstructor()
    {
        $this->urlMask = new Url([
            'replacement' => '_',
            'params' => ['foo']
        ]);

        $this->assertSame('xyz://abc.de/fge?foo=___&bar=baz', $this->urlMask->mask('xyz://abc.de/fge?foo=123&bar=baz'));
    }

    /**
     * Test the mask function
     */
    public function testMask()
    {
        foreach ($this->validUrls as $input => $output) {
            $this->assertSame($output, $this->urlMask->mask($input));
        }

        foreach ($this->invalidUrls as $input) {
            $this->assertSame($input, $this->urlMask->mask($input));
        }
    }
}
