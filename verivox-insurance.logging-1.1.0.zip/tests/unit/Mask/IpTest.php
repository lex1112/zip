<?php

namespace Insurance\LoggingTest\Mask;

use Insurance\Logging\Mask\Ip;

/**
 * Testing class for ip masking.
 */
class IpTest extends \Codeception\Test\Unit
{

    /**
     * @var array Strings containing valid ips with their masked variant
     */
    protected $validIps = [
        '[2018-03-20 14:23:36] lumen.ERROR: GuzzleHttp\Exception\ClientException: Client error: `GET https://test.org/foo?USER_IP=192.168.1.42-12345'
            => '[2018-03-20 14:23:36] lumen.ERROR: GuzzleHttp\Exception\ClientException: Client error: `GET https://test.org/foo?USER_IP=V3i+JfZdw3iyks76zqHrMQ==-12345',
        '127.0.0.1' => 'zb4e22i/7CXfrMkrDkT+mQ=='
    ];

    /**
     * @var array Strings without any ip masking
     */
    protected $invalidIps = [
        'This string doesn\'t contain an ip',
        'This string contains a number that looks almost like an ip: 200.000.000.000 €',
        'This string contains a number that looks almost like an ip: 300.0.0.0',
        'This string contains a number that looks almost like an ip: 127:0:0:0',
    ];

    /**
     * @var Ip
     */
    protected $ipMask;

    protected function setUp()
    {
        $this->ipMask = new Ip();
    }

    /**
     * Test that the constructor works
     */
    public function testConstructor()
    {
        $this->ipMask = new Ip([
            'cipher' => 'aes128',
            'key' => 'foo',
        ]);

        $this->assertSame('r25yS05jsVGFLVQUmLC8xg==', $this->ipMask->mask('127.0.0.1'));
    }

    /**
     * Test the mask function
     */
    public function testMask()
    {
        foreach ($this->validIps as $input => $output) {
            $this->assertSame($output, $this->ipMask->mask($input));
        }

        foreach ($this->invalidIps as $input) {
            $this->assertSame($input, $this->ipMask->mask($input));
        }
    }
}
