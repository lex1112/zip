<?php

namespace Insurance\LoggingTest\unit;

use Insurance\Logging\Exception\RequestException;
use Insurance\Logging\MiddlewareErrorHandler;
use GuzzleHttp\Middleware;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\MessageFormatter;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use Psr\Log\Test\TestLogger;

/**
 * Class MiddlewareErrorHandlerTest
 *
 * @author    George Haroun <george.haroun@verviox.com>
 * @copyright Copyright (c) 2019 Verivox
 */
class MiddlewareErrorHandlerTest extends \Codeception\Test\Unit
{

    /**
     * @expectedException \GuzzleHttp\Exception\ClientException
     */
    public function testThrowsExceptionOnHttpClientError()
    {
        $m = MiddlewareErrorHandler::httpErrors();
        $h = new MockHandler([new Response(404)]);
        $f = $m($h);
        $p = $f(new Request('GET', 'http://foo.com'), ['http_errors' => true]);
        $this->assertSame('pending', $p->getState());
        $p->wait();
        $this->assertSame('rejected', $p->getState());
    }

    /**
     * @expectedException \GuzzleHttp\Exception\ServerException
     */
    public function testThrowsExceptionOnHttpServerError()
    {
        $m = MiddlewareErrorHandler::httpErrors();
        $h = new MockHandler([new Response(500)]);
        $f = $m($h);
        $p = $f(new Request('GET', 'http://foo.com'), ['http_errors' => true]);
        $this->assertSame('pending', $p->getState());
        $p->wait();
        $this->assertSame('rejected', $p->getState());
    }

    public function testTracksHistoryForFailures()
    {
        $container = [];
        $m = Middleware::history($container);
        $request = new Request('GET', 'http://foo.com');
        $h = new MockHandler([new RequestException('error', $request)]);
        $f = $m($h);
        $f($request, [])->wait(false);
        $this->assertCount(1, $container);
        $this->assertSame('GET', $container[0]['request']->getMethod());
        $this->assertInstanceOf(RequestException::class, $container[0]['error']);
    }

    public function testLogsRequestsAndErrors()
    {
        $h = new MockHandler([new Response(404)]);
        $stack = new HandlerStack($h);
        $logger = new TestLogger();
        $formatter = new MessageFormatter('{code} {error}');
        $stack->push(Middleware::log($logger, $formatter));
        $stack->push(MiddlewareErrorHandler::httpErrors());
        $comp = $stack->resolve();
        $p = $comp(new Request('PUT', 'http://www.google.com'), ['http_errors' => true]);
        $p->wait(false);
        $this->assertCount(1, $logger->records);
        $this->assertContains('PUT http://www.google.com', $logger->records[0]['message']);
        $this->assertContains('404 Not Found', $logger->records[0]['message']);
    }
}
