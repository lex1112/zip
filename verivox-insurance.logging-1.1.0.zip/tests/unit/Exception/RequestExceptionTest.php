<?php

namespace Insurance\LoggingTest\unit\Exception;

use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use Insurance\Logging\Exception\RequestException;

/**
 * Class RequestExceptionTest
 *
 * @author    George Haroun <george.haroun@verviox.com>
 * @copyright Copyright (c) 2019 Verivox
 */
class RequestExceptionTest extends \Codeception\Test\Unit
{

    public function testCreatesExceptionWithPrintableBodySummary()
    {
        $content = '"error":{"code":422,"message":"Unprocessable Entity","details":{"You broke the test!"}}';
        $response = new Response(422, [], $content);
        $e = RequestException::create(new Request('GET', '/'), $response);
        $this->assertContains($content, $e->getMessage());
        $this->assertInstanceOf('GuzzleHttp\Exception\RequestException', $e);
    }

    public function testCreatesExceptionWithTruncatedSummary()
    {
        $content = str_repeat('+', 1001);
        $response = new Response(500, [], $content);
        $e = RequestException::create(new Request('GET', '/'), $response);
        $expected = str_repeat('+', 1000) . ' (truncated...)';
        $this->assertContains($expected, $e->getMessage());
        $this->assertInstanceOf('\GuzzleHttp\Exception\ServerException', $e);
    }

    public function testCreatesExceptionWithoutTruncatedSummary()
    {
        $content = str_repeat('+', 1000);
        $response = new Response(700, [], $content);
        $e = RequestException::create(new Request('GET', '/'), $response);
        $this->assertContains($content, $e->getMessage());
        $this->assertInstanceOf('\GuzzleHttp\Exception\RequestException', $e);
    }

    public function testExceptionMessageIgnoresEmptyBody()
    {
        $e = RequestException::create(new Request('GET', '/'), new Response(500));
        $this->assertStringEndsWith('response', $e->getMessage());
    }
}
