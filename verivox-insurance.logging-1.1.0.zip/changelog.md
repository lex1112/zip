##Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [1.2.0] - 2019-12-11
### Changed
- truncation of request exceptions increased from 200 to 1000 characters

## [1.1.0] - 2019-01-16
### Added
- Added middleware error handler to override the throw exceptions in RequestException and increase the truncate range of error messages

## [1.0.1] - 2018-04-13
### Bug
- remove the useless double base64 encoding from the ip encryption algorithm
- fixed assumption of the algorithm for the IP mask

## [1.0.0] - 2018-04-12
### Changed
- the encryption algorithm for the ip mask from aes256 to aes128-cbc with a new key and addtional base64 encryption

## [0.1.0] - 2018-03-22
### Added
- Init Commit
- Wrap logger instance with masking
- Added masking for emails, ips and url get parameters
