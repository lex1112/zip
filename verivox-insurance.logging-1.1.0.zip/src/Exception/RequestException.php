<?php

namespace Insurance\Logging\Exception;

use Psr\Http\Message\ResponseInterface;

/**
 * Class RequestException
 *
 * Thrown when a response was received but the request itself failed.
 * In addition to the request, this exception always provides access to the response object.
 *
 * @author    George Haroun <george.haroun@verviox.com>
 * @copyright Copyright (c) 2019 Verivox
 */
class RequestException extends \GuzzleHttp\Exception\RequestException
{

    /**
     * Get a short summary of the response
     *
     * Will return `null` if the response is not printable.
     *
     * @param ResponseInterface $response
     *
     * @return string|null
     */
    public static function getResponseBodySummary(ResponseInterface $response) : ?string
    {
        $body = $response->getBody();

        if (!$body->isSeekable()) {
            return null;
        }

        $size = $body->getSize();

        if ($size === 0) {
            return null;
        }

        $summary = $body->read(1000);
        $body->rewind();

        if ($size > 1000) {
            $summary .= ' (truncated...)';
        }

        // Matches any printable character, including unicode characters:
        // letters, marks, numbers, punctuation, spacing, and separators.
        if (preg_match('/[^\pL\pM\pN\pP\pS\pZ\n\r\t]/', $summary)) {
            return null;
        }

        return $summary;
    }
}
