<?php

namespace Insurance\Logging;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Formatter\LineFormatter;
use Pachico\Magoo\Magoo;
use Pachico\Magoo\MagooArray;
use Insurance\Logging\Mask;

/**
 * Class MaskedMonologLogger
 */
class MaskedMonologLogger extends Logger
{
    /**
     * @var Magoo
     */
    private $stringMaskManager;

    /**
     * @var MagooArray
     */
    private $arrayMaskManager;

    /**
     * MaskedMonologLogger constructor.
     * @param string $name
     * @param array $handlers
     * @param array $processors
     * @param Magoo|null $maskManager
     */
    public function __construct(string $name, $handlers = [], $processors = [], Magoo $maskManager = null)
    {
        if (null === $maskManager) {
            $maskManager = self::fetchDefaultMasks();
        }
        $this->stringMaskManager = $maskManager;
        $this->arrayMaskManager = new MagooArray($maskManager);

        parent::__construct($name, $handlers, $processors);
    }

    /**
     * add masked log record
     *
     * @param int $level
     * @param string $message
     * @param array $context
     * @return bool|void
     * @throws \Exception
     */
    public function addRecord($level, $message, array $context = array())
    {
        $maskedMessage = $this->stringMaskManager->getMasked((string) $message);
        $maskedContext = $this->arrayMaskManager->getMasked($context);

        parent::addRecord($level, $maskedMessage, $maskedContext);
    }

    /**
     * Create a masked monolog instance with default name and handler
     *
     * @param Magoo|null $maskManager
     *
     * @return MaskedMonologLogger
     * @throws \Exception
     */
    public static function createDefaultLumenLogger(Magoo $maskManager = null) {
        return new self(
            'lumen',
            [
                (new StreamHandler(storage_path('logs/lumen.log'), Logger::DEBUG))
                    ->setFormatter(new LineFormatter(null, null, true, true))
            ],
            [],
            $maskManager ?: static::fetchDefaultMasks()
        );
    }

    /**
     * get the default masks for the monologger
     *
     * @return Magoo
     */
    public static function fetchDefaultMasks(): Magoo {
        //create default masking
        $maskManager = new Magoo();
        $maskManager
            ->pushCreditCardMask()
            ->pushEmailMask()
            ->pushMask(new Mask\Ip())
            ->pushMask(new Mask\Url(['params' => ['dateOfBirth', 'street', 'streetNumber', 'firstName', 'lastName', 'givenName', 'familyName']]));

        return $maskManager;
    }
}