<?php

namespace Insurance\Logging\Mask;

use Pachico\Magoo\Mask\MaskInterface;

/**
 * Masking class for urls
 */
class Url implements MaskInterface
{
    /**
     * @var string
     */
    protected $replacement = '*';

    /**
     * @var array
     */
    protected $params = [];

    /**
     * {@inheritDoc}
     */
    public function __construct(array $params = [])
    {
        if (isset($params['replacement']) && is_string($params['replacement'])) {
            $this->replacement = $params['replacement'];
        }
        if (isset($params['params']) && is_array($params['params'])) {
            $this->params = $params['params'];
        }
    }

    /**
     * @param string $match
     *
     * @return string
     */
    protected function maskIndividualUrlMatch(string $match): string
    {
        $url = parse_url($match);
        $returnUrl = '';

        if (isset($url['scheme'])) {
            $returnUrl = $url['scheme'] . "://";
        }

        if (isset($url['host'])) {
            $returnUrl .= $url['host'];
        }

        if (isset($url['path'])) {
            $returnUrl .= $url['path'];
        }

        if (isset($url['query'])) {
            $params = [];
            parse_str($url['query'], $params);

            // mask the configured parameters, if included in the url
            foreach ($this->params as $param) {
                if (isset($params[$param])) {
                    $params[$param] = str_repeat($this->replacement, strlen($params[$param]));
                }
            }
            $returnUrl .= '?' . urldecode(http_build_query($params));
        }

        if (isset($url['fragment'])) {
            $returnUrl .= "#" . $url['fragment'];
        }

        return $returnUrl;
    }

    /**
     * {@inheritDoc}
     */
    public function mask($string): string
    {
        $regex = '~(?P<url>[a-z]+://[^\r\n\t`]+)~';

        $matches = [];
        preg_match_all($regex, $string, $matches);

        if (!isset($matches['url']) || empty($matches['url'])) {
            return $string;
        }
        foreach ($matches['url'] as $match) {
            $string = str_replace($match, $this->maskIndividualUrlMatch($match), $string);
        }

        return $string;
    }
}