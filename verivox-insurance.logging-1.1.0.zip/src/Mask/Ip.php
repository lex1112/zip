<?php

namespace Insurance\Logging\Mask;

use Pachico\Magoo\Mask\MaskInterface;

/**
 * Masking class for ips
 */
class Ip implements MaskInterface
{
    /**
     * @var string
     */
    protected $cipher = 'aes-128-cbc';

    /**
     * @var string
     */
    protected $key = '#vx#-*insurance#';

    /**
     * {@inheritDoc}
     */
    public function __construct(array $params = [])
    {
        if (isset($params['cipher']) && is_string($params['cipher'])) {
            $this->cipher = $params['cipher'];
        }
        if (isset($params['key']) && is_string($params['key'])) {
            $this->key = $params['key'];
        }
    }

    /**
     * @param string $match
     *
     * @return string
     */
    protected function maskIndividualIpMatch(string $match): string
    {
        return openssl_encrypt($match, $this->cipher, $this->key, 0, '0123456789abcdef');
    }

    /**
     * {@inheritDoc}
     */
    public function mask($string): string
    {
        $re = '/(?:\D|\G|^)(?P<ip>([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){3})(?:\D|$)/';

        $matches = [];
        preg_match_all($re, $string, $matches);
        if (!isset($matches['ip']) || empty($matches['ip'])) {
            return $string;
        }
        foreach ($matches['ip'] as $match) {
            $string = str_replace($match, $this->maskIndividualIpMatch($match), $string);
        }

        return $string;
    }
}